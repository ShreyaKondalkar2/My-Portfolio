package com.start;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.dao.Create_Dao_imp;
import com.dao.insert_dao_imp;

/**
 * Application Lifecycle Listener implementation class Begin
 *
 */
public class Begin implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public Begin() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	Create_Dao_imp c=new Create_Dao_imp();
    	c.createDatabase();
    	c.createTable();
    	new insert_dao_imp().adminInfo();
    	}
	
}
