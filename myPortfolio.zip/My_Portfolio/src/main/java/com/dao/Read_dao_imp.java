package com.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.pojo.Admin;
import com.pojo.Education;
import com.pojo.Experience;
import com.pojo.Message;
import com.pojo.Profile;
import com.pojo.Project;

public class Read_dao_imp implements Read {
	private ArrayList<Message> al=new ArrayList<Message>();
	private ArrayList<Project> al1=new ArrayList<Project>();
	private ArrayList<Education> al2=new ArrayList<Education>();
	private ArrayList<Admin> al3=new ArrayList<Admin>();
	private ArrayList<Experience> al4=new ArrayList<Experience>();
	private String result;
	@SuppressWarnings("finally")
	public ArrayList<Message> readMessage()
	{
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.message");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				al.add(new Message(rs.getInt("sn"),rs.getString("name"), rs.getString("email"), rs.getString("message"),rs.getString("date")));

			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		}
		finally
		{
		return al;
		}
		
		
		
	}
	@SuppressWarnings("finally")
	@Override
	public String adminCheck(String username, String pass) {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.admin where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			if(rs.next()==true)
			{
				result="exist";
			}
			else
			{
				result="invalid";
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="exp";
			System.out.println("Inside adminCheck->"+e);
		}
		finally
		{
			return result;
		}
		
	}
	@SuppressWarnings("finally")
	@Override
	public ArrayList<Project> readProject() {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.project");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				al1.add(new Project(rs.getInt("sn"),rs.getString("filename")));
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		}
		finally
		{
		  return al1;
		}
	}
	@SuppressWarnings("finally")
	@Override
	public ArrayList<Education> readEducation() {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.education");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				al2.add(new Education(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		}
		finally
		{
		  return al2;
		}
	}
	@SuppressWarnings("finally")
	@Override
	public Admin readAdmin() {
		Admin a = null;
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.admin");
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
			 a =new Admin(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		 }
		finally
		{
		   return a;
		}
	}
	@Override
	public Profile readProfile() {
		Profile p =null;
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.Profile");
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				p.setSn(rs.getInt(1));
				p.setFname(rs.getString(2));
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		}
		finally
		{
		 return p;
		}
		
	}
	@Override
	public ArrayList<Experience> readExperience() {
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from MyPortfolio.experience");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				al4.add(new Experience(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Inside read->"+e);
		}
		finally
		{
		  return al4;
		}
	}

}
