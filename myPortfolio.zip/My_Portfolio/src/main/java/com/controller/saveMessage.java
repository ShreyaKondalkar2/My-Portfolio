package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Delete_dao_imp;
import com.dao.insert_dao_imp;
import com.validation.Validation;

/**
 * Servlet implementation class saveMessage
 */
public class saveMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s=request.getSession();
		String check=request.getParameter("check");
		if(check!=null)
		{
			String sn=request.getParameter("sn");
			String res=new Delete_dao_imp().deleteMessage(Integer.parseInt(sn));
			if(res.equals("deleted"))
			{
				s.setAttribute("msg", "Message deleted successfully");
				response.sendRedirect("ReadMessage.jsp");
			}
			else
			{
				s.setAttribute("msg", "Something wentwrong");
				response.sendRedirect("ReadMessage.jsp");
			}
		}
		else
		{
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String message=request.getParameter("message");
		
		String res1=new Validation().Validate_message( name, email, message);
		if(res1.equals("valid"))
		{
			String res2=new insert_dao_imp().save_Message(name,email,message);
			if(res2.equals("saved"))
			{
				s.setAttribute("msg", "Message sent Successfully");
				response.sendRedirect("index.jsp");
			}
			else
				
			{
				s.setAttribute("msg", "Something Went Wrong");
				response.sendRedirect("index.jsp");
			}
		}
		else
		{
			s.setAttribute("msg",res1);
		    response.sendRedirect("index.jsp");
		}
		}//end check
	}

}
