package com.dao;

public interface Update_dao {
	public String UpdateCredential(String username,String pass, int sn);

}
