package com.controller;

import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DownloadResume
 */
public class DownloadResume extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String filename="MyResume.pdf";
		String path = "C:\\Users\\santo\\OneDrive\\Desktop\\shreya_java\\My_Portfolio\\src\\main\\webapp\\myresume\\"
				+filename;
		FileInputStream fis = new FileInputStream(path);
		byte[] b = fis.readAllBytes();
		ServletOutputStream sos = response.getOutputStream();
		sos.write(b);
		response.setHeader("content-disposition", "filename=myresume.pdf");
		response.setContentType("application/octet-stream");
		fis.close();
		sos.close();
	}

}
