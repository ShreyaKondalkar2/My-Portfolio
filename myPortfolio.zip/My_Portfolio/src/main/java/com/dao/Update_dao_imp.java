package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.jsp.tagext.TryCatchFinally;

public class Update_dao_imp implements Update_dao {
private String result;

@Override
public String UpdateCredential(String username, String pass, int sn) {
	// TODO Auto-generated method stub
	try {
		Connection con = ConnectionFactory.getConnection();
		String sql="update MyPortfolio.admin set username=? , password=? where sn=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, username);
		ps.setString(2, pass);
		ps.setInt(3, sn);
		int row = ps.executeUpdate();
		if(row==1)
		{
			result="updated";
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		result="exp";
		System.out.println("inside update dao imp->"+e);
		e.printStackTrace();
	}
	return result;
}
	
	

}
