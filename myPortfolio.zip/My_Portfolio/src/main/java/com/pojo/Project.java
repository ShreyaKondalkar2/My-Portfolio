package com.pojo;

public class Project {
private int sn;
private String fname;
public int getSn() {
	return sn;
}
public Project(int sn, String fname) {
	super();
	this.sn = sn;
	this.fname = fname;
}

public String getFname() {
	return fname;
}


@Override
public String toString() {
	return "Project [sn=" + sn + ", fname=" + fname + "]";
}

}
