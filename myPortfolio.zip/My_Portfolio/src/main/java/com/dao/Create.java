package com.dao;

public interface Create {
	public void createTable();
	public void createDatabase();
}
