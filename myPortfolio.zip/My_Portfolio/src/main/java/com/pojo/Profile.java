package com.pojo;

public class Profile {
private int sn;
private String fname;
public Profile(int sn, String fname) {
	super();
	this.sn = sn;
	this.fname = fname;
}
public int getSn() {
	return sn;
}
public void setSn(int sn) {
	this.sn = sn;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}


}
