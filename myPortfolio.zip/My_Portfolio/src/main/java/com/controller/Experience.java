package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.insert_dao_imp;

/**
 * Servlet implementation class Experience
 */
public class Experience extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Experience() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s = request.getSession();
		String year=request.getParameter("year");
		String title=request.getParameter("title");
		String subtitle=request.getParameter("subtitle");
		String description=request.getParameter("description");
		String res=new insert_dao_imp().save_experience(year, title, subtitle, description);
		if(res.equals("saved"))
		{
			s.setAttribute("msg", "Experience added successfully");
			response.sendRedirect("admin.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("experience.jsp");
		}
	}

}
