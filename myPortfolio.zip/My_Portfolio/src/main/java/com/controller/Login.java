package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Read_dao_imp;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String pass=request.getParameter("pass");
		HttpSession s=request.getSession();
		String res=new Read_dao_imp().adminCheck(username,pass);
		if(res.equals("exist"))
		{
			s.setAttribute("login", username);
			response.sendRedirect("admin.jsp");
		}
		else if(res.equals("invalid"))
		{
			s.setAttribute("msg", "Invalid username or password");
			response.sendRedirect("adminAuth.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("adminAuth.jsp");
		}
		
	}

}
