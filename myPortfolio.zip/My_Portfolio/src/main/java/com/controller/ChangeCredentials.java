package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Update_dao_imp;

/**
 * Servlet implementation class ChangeCredentials
 */
public class ChangeCredentials extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s = request.getSession();
		String username = request.getParameter("username");
		String pass = request.getParameter("password");
		String sn = request.getParameter("sn");
		String res=new Update_dao_imp().UpdateCredential(username, pass, Integer.parseInt(sn));
		if(res.equals("updated"))
		{
			s.setAttribute("msg", "Credentials changed successfully");
			response.sendRedirect("admin.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("ChangeCredential.jsp");
		}
		
	}

}
