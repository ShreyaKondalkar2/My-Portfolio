package com.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.validation.Validation;

/**
 * Servlet implementation class uploadResume
 */
@MultipartConfig
public class uploadResume extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public uploadResume() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s = request.getSession();
		Part part = request.getPart("resume");
		String res=new Validation().ValidFile(part);
		if(res.equals("valid"))
		{
		try {
			InputStream is = part.getInputStream();
			byte[] b = is.readAllBytes();
			String filename = "MyResume.pdf";
			String path = "C:\\Users\\santo\\OneDrive\\Desktop\\shreya_java\\My_Portfolio\\src\\main\\webapp\\myresume\\"
					+ filename;
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(b);
			is.close();
			fos.close();
			s.setAttribute("msg", "resume uploaded successfully");
			response.sendRedirect("uploadResume.jsp");
		} catch (Exception e) {
			// TODO: handle exception
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("uploadResume.jsp");
		}
		}
		else
		{
			s.setAttribute("msg", res);
			response.sendRedirect("uploadResume.jsp");
		}
	}

}
