package com.dao;

import java.sql.Connection;
import java.sql.Statement;



public class Create_Dao_imp implements Create{
	
		public void createDatabase()
		{
			try {
				Connection con=ConnectionFactory.getConnection();
				Statement st=con.createStatement();
				st.execute("create database MyPortfolio");
				System.out.println("Database created");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				
				e.printStackTrace();
			}
		}
		public void createTable()
		{
		try
		{
			Connection con=ConnectionFactory.getConnection();
			Statement st=con.createStatement();
			String sql="create table  myportfolio.message(sn int primary key auto_increment,name varchar(30),email varchar(50),message varchar(30))";
			st.execute(sql);
			System.out.println("Table created");
		} catch (Exception e) {
			// TODO Auto-generated catch block
		
			System.out.println("Create table1->"+e);
			
			e.printStackTrace();
		}
		finally
		{
			try
			{
				Connection con=ConnectionFactory.getConnection();
				Statement st=con.createStatement();
				String sql="create table  myportfolio.admin(sn int primary key auto_increment,username varchar(30),password varchar(50))";
				st.execute(sql);
				System.out.println("Table created");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Create table2->"+e);
				
				e.printStackTrace();
			}
			finally
			{
				try
				{
					Connection con=ConnectionFactory.getConnection();
					Statement st=con.createStatement();
					String sql="create table  myportfolio.project(sn int primary key auto_increment,filename varchar(100))";
					st.execute(sql);
					System.out.println("Table created");
				} catch (Exception e) {
					// TODO Auto-generated catch block
				
					System.out.println("Create table1->"+e);
					
					e.printStackTrace();
				}
				finally
				{
					try
					{
						Connection con=ConnectionFactory.getConnection();
						Statement st=con.createStatement();
						String sql="create table  myportfolio.Education(sn int primary key auto_increment,year varchar(30),title varchar(50),subtitle varchar(30),Description varchar(50))";
						st.execute(sql);
						System.out.println("Table created");
					} catch (Exception e) {
						// TODO Auto-generated catch block
					
						System.out.println("Create table4->"+e);
						
						e.printStackTrace();
					}
					finally
					{
						try
						{
							Connection con=ConnectionFactory.getConnection();
							Statement st=con.createStatement();
							String sql="create table  myportfolio.experience(sn int primary key auto_increment,year varchar(30),title varchar(50),subtitle varchar(30),Description varchar(50))";
							st.execute(sql);
							System.out.println("Table created");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						
							System.out.println("Create table4->"+e);
							
							e.printStackTrace();
						}
						finally
						{
						
						}
						}
					}
					}
				}
			}
		}


	
