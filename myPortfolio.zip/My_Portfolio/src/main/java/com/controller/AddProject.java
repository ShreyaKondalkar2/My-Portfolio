package com.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.dao.insert_dao_imp;

/**
 * Servlet implementation class AddProject
 */
@MultipartConfig
public class AddProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s = request.getSession();
		Part part = request.getPart("fname");
		String fname = part.getSubmittedFileName();
		String res=new insert_dao_imp().save_project(fname);
		if(res.equals("saved"))
		{
		 InputStream is = part.getInputStream();
		 byte[] b = is.readAllBytes();
		 String path="C:\\Users\\santo\\OneDrive\\Desktop\\shreya_java\\My_Portfolio\\src\\main\\webapp\\images\\myproject\\"+fname;
		 FileOutputStream fos=new FileOutputStream(path);
		 fos.write(b);
		 s.setAttribute("msg", "project added successfully");
		 response.sendRedirect("admin.jsp");
		}
		else
		{
			 s.setAttribute("msg", "something went wrong");
			 response.sendRedirect("addproject.jsp");
		}
	}

}
