package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Delete_dao_imp;

/**
 * Servlet implementation class DeleteEdu
 */
public class DeleteEdu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession s = request.getSession();
		String sn = request.getParameter("sn");
		String res=new Delete_dao_imp().deleteeducation(Integer.parseInt(sn));
		if(res.equals("deleted"))
		{
			s.setAttribute("msg", "Education deleted successfully");
			response.sendRedirect("readeducation.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("readeducation.jsp");
		}
	
	}

}
