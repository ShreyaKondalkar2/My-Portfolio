package com.dao;
import java.sql.Connection;
import com.mysql.cj.jdbc.MysqlDataSource;
class ConnectionFactory
{
	private static Connection con;
	public  static Connection getConnection() throws Exception
	{
		MysqlDataSource sd=new MysqlDataSource();
		sd.setUrl("jdbc:mysql://localhost:3306");
		sd.setUser("root");
		sd.setPassword("Shreya@2110");
		con=sd.getConnection();
		return con;
	}
}