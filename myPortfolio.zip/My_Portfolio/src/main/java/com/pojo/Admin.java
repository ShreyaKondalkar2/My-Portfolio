package com.pojo;

public class Admin {
	private int sn;
	private String username;
	private String pass;
	public Admin(int sn, String username, String pass) {
		super();
		this.sn = sn;
		this.username = username;
		this.pass = pass;
	}
	public int getSn() {
		return sn;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPass() {
		return pass;
	}
}
