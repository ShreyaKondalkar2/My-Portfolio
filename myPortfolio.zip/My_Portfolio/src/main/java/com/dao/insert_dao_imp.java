package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;

public class insert_dao_imp implements insert_dao{
	private String result;
	@SuppressWarnings("finally")
	public String save_Message(String name,String email,String message)
	{
		try {
			Connection con=ConnectionFactory.getConnection();
			String sql="insert into MyPortfolio.message(name,email,message,date) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, message);
			ps.setString(4,LocalDateTime.now().toString());
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="saved";
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Insert_dao_imp"+e);
			result="not_saved";
		}
		finally
		{
		   return result;
		}
	}
	public String adminInfo() {
		try {
		Connection con=ConnectionFactory.getConnection();
    	PreparedStatement st = con.prepareStatement("Select * from MyPortfolio.admin where sn=1");
		ResultSet rs=st.executeQuery();
		if(rs.next()!=true) {
	
			
			String sql="insert into MyPortfolio.admin(username,password) values('admin','admin')";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.execute();
			result="saved";
		}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Insert_dao_imp->adminInfo"+e);
			result="not_saved";
		}
		finally
		{
		   return result;
		}
	}
	@Override
	public String save_project(String fname) {
		try {
			Connection con=ConnectionFactory.getConnection();
			
			
			String sql="insert into MyPortfolio.project(filename) values(?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, fname);
			
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="saved";
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Insert_dao_imp"+e);
			result="not_saved";
		}
		finally
		{
		   return result;
		}
	}
	@Override
	public String save_education(String year, String title, String subtitle, String description) {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			String sql="insert into MyPortfolio.education(year,title,subtitle,description) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, year);
			ps.setString(2, title);
			ps.setString(3, subtitle);
			ps.setString(4,description);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="saved";
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Insert_dao_imp"+e);
			result="not_saved";
		}
		finally
		{
		   return result;
		}
		
	}
	@Override
	public String save_experience(String year, String title, String subtitle, String description) {
		try {
			Connection con=ConnectionFactory.getConnection();
			String sql="insert into MyPortfolio.experience(year,title,subtitle,description) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, year);
			ps.setString(2, title);
			ps.setString(3, subtitle);
			ps.setString(4,description);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="saved";
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Insert_dao_imp"+e);
			result="not_saved";
		}
		finally
		{
		   return result;
		}
	}


}
