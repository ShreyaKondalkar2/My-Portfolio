package com.dao;

public interface insert_dao {
	public String save_Message(String name,String email,String message);
	public String adminInfo(); 
	public String save_project(String fname);
	public String save_education(String year,String title,String subtitle,String description);
	public String save_experience(String year,String title,String subtitle,String description);
}
