package com.dao;

import java.util.ArrayList;

import com.pojo.Admin;
import com.pojo.Education;
import com.pojo.Experience;
import com.pojo.Message;
import com.pojo.Profile;
import com.pojo.Project;

public interface Read {
	public ArrayList<Message> readMessage();
	public String adminCheck(String username,String pass);
	public ArrayList<Project>readProject();
	public ArrayList<Education>readEducation();
	public ArrayList<Experience>readExperience();
	public Admin readAdmin();
	public Profile readProfile();
}
