package com.controller;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Delete_dao_imp;

/**
 * Servlet implementation class DeleteProject
 */
public class DeleteProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteProject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		String sn=request.getParameter("sn");
		String filename=request.getParameter("fname");
		String res=new Delete_dao_imp().deleteProject(Integer.parseInt(sn));
		String path="C:\\Users\\santo\\OneDrive\\Desktop\\shreya_java\\My_Portfolio\\src\\main\\webapp\\images\\myproject\\"+filename;
		if(res.equals("deleted"))
		{
			File f=new File(path);
			f.delete();
			s.setAttribute("msg", "project deleted successfully");
			response.sendRedirect("readProject.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("readProject.jsp");
		}
		
	}

}
