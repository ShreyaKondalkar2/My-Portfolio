package com.validation;

import javax.servlet.http.Part;

public class Validation {
	private String result;
	
	public String Validate_message(String name,String email,String message)
	{
		int r;
		r=check_alpha(name);
		if(name.length()<2||name.length()>10)
		{
			
			if(r==0)
			{
				result="invalid name";
			}
		}
		else if(r==0)
		{
			{
				result="invalid name";
			}
		}
		else if(!email.endsWith(".com"))
		{
			result="invalid email";
		}
		else if(message.length()<2 || message.length()>30)
		{
			result="invalid message";
		}
		else
		{
			result="valid";
		}
		return result;
	}
	private int check_alpha(String name) {
		// TODO Auto-generated method stub
		byte b[]=name.getBytes();
		int flag=0;
		for(byte b1:b)
		{
			if((b1<96||b1>123))
			{
				flag=1;
				break;
			}
			
		}
		if(flag==1)
		{
			return 0;
		}
		else
		{
		   return 1;
		}
		
	}
	public String ValidFile(Part part) {
		if(!part.getContentType().endsWith("pdf"))
		{
			result="invalid file formate";
		}
		else if(part.getSize()>=406800)
		{
			result="File size is larger than limit";
		}
		else
		{
			result="valid";
		}
		return result;
		// TODO Auto-generated method stub
		
	}
	public String validProfile(Part part)
	{
		if(!part.getContentType().endsWith("jpeg"))
		{
			result="invalid file formate";
		}
		else if(part.getSize()>=204800)
		{
			result="File size is larger than limit";
		}
		else
		{
			result="valid";
		}
		return result;
	}

}
