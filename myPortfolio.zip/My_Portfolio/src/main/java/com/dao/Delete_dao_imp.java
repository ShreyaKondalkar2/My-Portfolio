package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Delete_dao_imp implements Delete_dao {
private String result;
	@Override
	public String deleteMessage(int sn) {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from MyPortfolio.message where sn=?");
			ps.setInt(1, sn);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="deleted";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result="exp";
			System.out.println("inside delete->"+e);
			e.printStackTrace();
		}
		finally
		{
		  return result;
		}
	}
	@Override
	public String deleteProject(int sn) {
		// TODO Auto-generated method stub
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from MyPortfolio.Project where sn=?");
			ps.setInt(1, sn);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="deleted";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result="exp";
			System.out.println("inside delete->"+e);
			e.printStackTrace();
		}
		finally
		{
		  return result;
		}
	}
	@Override
	public String deleteeducation(int sn) {
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from MyPortfolio.education where sn=?");
			ps.setInt(1, sn);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="deleted";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result="exp";
			System.out.println("inside delete->"+e);
			e.printStackTrace();
		}
		finally
		{
		  return result;
		}
	}
	@Override
	public String deleteexperience(int sn) {
		try {
			Connection con=ConnectionFactory.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from MyPortfolio.experience where sn=?");
			ps.setInt(1, sn);
			int row=ps.executeUpdate();
			if(row==1)
			{
				result="deleted";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result="exp";
			System.out.println("inside delete->"+e);
			e.printStackTrace();
		}
		finally
		{
		  return result;
		}
	}

}
