package com.dao;

public interface Delete_dao {
public String deleteMessage(int sn);
public String deleteProject(int sn);
public String deleteeducation(int sn);
public String deleteexperience(int sn);
}
