package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Delete_dao_imp;

/**
 * Servlet implementation class deleteExp
 */
public class deleteExp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteExp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		String sn = request.getParameter("sn");
		String res=new Delete_dao_imp().deleteexperience(Integer.parseInt(sn));
		if(res.equals("deleted"))
		{
			s.setAttribute("msg", "Education deleted successfully");
			response.sendRedirect("readexperience.jsp");
		}
		else
		{
			s.setAttribute("msg", "something went wrong");
			response.sendRedirect("readeducation.jsp");
		}
	
	}

}
